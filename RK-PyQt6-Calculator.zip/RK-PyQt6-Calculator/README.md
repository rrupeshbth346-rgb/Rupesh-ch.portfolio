# 🧮 RK PyQt6 Calculator

A simple desktop calculator application built with Python and PyQt6.

## ✨ Features

- Addition (+)
- Subtraction (-)
- Multiplication (*)
- Division (/)
- Percentage (%)
- Square Root (√)
- Power (^)
- Decimal numbers
- Brackets
- Clear button
- Graphical User Interface

## 🛠️ Technologies

- Python
- PyQt6
- math module

## 🚀 Installation

Install Python, then install PyQt6:

```bash
pip install -r requirements.txt
```

## ▶️ Run

```bash
python calculator.py
```

## 📂 Project Structure

```text
RK-PyQt6-Calculator/
├── calculator.py
├── README.md
├── requirements.txt
├── .gitignore
├── LICENSE
└── assets/
    └── screenshot.png
```

## 👨‍💻 Author

**Rupesh Chaurasiya**

BCA Student

## 📄 License

MIT License
